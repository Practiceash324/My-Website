# Ashish Mishra — Personal Brand Site

Real Vite + Tailwind v4 build. Not a CDN single-file page — this compiles, purges unused CSS, and minifies for production.

## Setup

```bash
npm install
```

## Development (live reload)

```bash
npm run dev
```
Opens at http://localhost:5173

## Production build

```bash
npm run build
```
Output goes to `dist/` — CSS is purged and minified (~31KB vs 300KB+ unpurged CDN Tailwind).

## Preview production build locally

```bash
npm run preview
```

## Deploy

`dist/` is a static folder — deploy to any static host:
- **Cloudflare Pages**: connect the GitHub repo, build command `npm run build`, output dir `dist`
- **Netlify**: same, build command `npm run build`, publish dir `dist`
- **Vercel**: auto-detects Vite

## Structure

```
index.html          — main page markup
src/style.css        — Tailwind v4 entry + custom @theme tokens (colors, fonts, spacing)
src/main.js          — renders dynamic sections (services, categories, FAQ, etc.), accordion logic
public/images/       — static assets (profile photo)
```

## Editing content

All copy lives directly in `index.html` (static sections) and `src/main.js` (data arrays — services, categories, features, comparison rows, FAQ). Edit the arrays in `main.js` to change dynamic section content without touching markup.

## Known placeholders — replace when ready

- `[Add Real Testimonial]` × 3 — testimonials section, `index.html`
- `[Add Video]` — demo section, `index.html`
- Case studies section — not currently included, add back when real project data exists

## Design tokens

Defined in `src/style.css` under `@theme`. Change `--color-violet`, `--color-blue`, `--color-green`, fonts, or spacing there — utilities regenerate automatically (Tailwind v4 CSS-first config, no `tailwind.config.js` needed).
