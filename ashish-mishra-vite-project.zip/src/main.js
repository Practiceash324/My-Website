import './style.css';

// Services
const services = [
  { tag: 'Performance Marketing', title: 'Google Ads & Meta Ads Management', desc: 'Campaign strategy, setup and conversion optimization across paid channels.', color: '#8b5cf6' },
  { tag: 'Analytics & Tracking', title: 'GA4, GTM & Server-Side Setup', desc: 'Data layer, event tracking, Consent Mode and enhanced ecommerce tracking.', color: '#3b82f6' },
  { tag: 'Consulting', title: 'Marketing Measurement Audit', desc: 'Full audit of campaign, tracking and analytics setup with a clear action plan.', color: '#10b981' },
  { tag: 'Training', title: 'Digital Marketing & Tracking Training', desc: 'Practical, industry-oriented sessions for individuals, teams and institutions.', color: '#f59e0b' },
];

document.getElementById('service-grid').innerHTML = services.map(s => `
  <div class="glass rounded-2xl overflow-hidden card-hover flex flex-col">
    <div class="aspect-video flex items-center justify-center" style="background:linear-gradient(135deg, ${s.color}22, #12121a)">
      <div class="w-12 h-12 rounded-full flex items-center justify-center" style="background:${s.color}33"><i class="fa-solid fa-chart-simple" style="color:${s.color}" aria-hidden="true"></i></div>
    </div>
    <div class="p-5 flex flex-col flex-1">
      <span class="text-[11px] font-medium text-violet-300">${s.tag}</span>
      <h3 class="font-display font-bold mt-1 mb-2">${s.title}</h3>
      <p class="text-sm text-gray-400 mb-4 flex-1">${s.desc}</p>
      <a href="#contact" class="focus-ring rounded text-sm font-medium text-violet-300 hover:text-violet-200 transition-colors">Request Details →</a>
    </div>
  </div>`).join('');

// Tools marquee
const tools = ['Google Ads', 'Meta Ads', 'GA4', 'Google Tag Manager', 'n8n', 'Make', 'Microsoft Clarity', 'Shopify', 'Firebase', 'AppsFlyer'];
const marqueeHTML = tools.map(t => `<div class="glass rounded-xl px-6 py-4 text-sm font-medium text-gray-400 whitespace-nowrap">${t}</div>`).join('');
document.getElementById('marquee-src').innerHTML = marqueeHTML;
document.getElementById('marquee-dup').innerHTML = marqueeHTML;

// Category grid
const categories = [
  { name: 'Students / Learners', badge: 'Individual', topics: 'Digital Marketing, GA4, GTM, Tracking, AI', items: ['Digital Marketing Foundation', 'GA4 & GTM Basics', 'AI for Marketing'], tags: ['Beginner-friendly', 'Hands-on', 'Practical'], dc: 'bg-green-500/15 text-green-300' },
  { name: 'Businesses', badge: 'Business', topics: 'Ads, Tracking, Measurement', items: ['Tracking Audit', 'Google/Meta Ads Setup', 'Conversion Tracking'], tags: ['Google Ads', 'Meta Ads', 'GA4'], dc: 'bg-blue-500/15 text-blue-300' },
  { name: 'Marketing Professionals', badge: 'Upskilling', topics: 'Advanced tracking & AI workflows', items: ['Server-Side Tracking', 'Consent Mode', 'AI-Assisted Workflows'], tags: ['n8n', 'Make', 'GTM'], dc: 'bg-amber-500/15 text-amber-300' },
  { name: 'Institutes / Organizations', badge: 'Corporate', topics: 'Workshops & structured training', items: ['Guest Sessions', 'Corporate Workshops', 'Seminar Training'], tags: ['Digital Marketing', 'Tracking', 'AI'], dc: 'bg-violet-500/15 text-violet-300' },
];

document.getElementById('category-grid').innerHTML = categories.map(c => `
  <div class="glass rounded-2xl p-5 card-hover flex flex-col">
    <div class="flex items-center justify-between mb-4 text-[11px]">
      <span class="px-2 py-1 rounded-full ${c.dc}">${c.badge}</span>
    </div>
    <h3 class="font-display font-bold mb-1">${c.name}</h3>
    <p class="text-xs text-gray-400 mb-3">${c.topics}</p>
    <ul class="text-sm text-gray-300 space-y-1 mb-4">
      ${c.items.map(i => `<li class="flex items-center gap-2"><span class="w-1 h-1 rounded-full bg-violet-400" aria-hidden="true"></span>${i}</li>`).join('')}
    </ul>
    <div class="flex flex-wrap gap-1.5 mb-5">
      ${c.tags.map(t => `<span class="text-[10px] border border-white/10 rounded-full px-2 py-0.5 text-gray-400">${t}</span>`).join('')}
    </div>
    <a href="#contact" class="btn focus-ring mt-auto text-center text-sm font-medium border border-white/15 rounded-full py-2 hover:bg-white/5">Get in Touch</a>
  </div>`).join('');

// Features
const features = [
  ['bullseye', 'Performance Marketing', 'Google Ads & Meta Ads campaign strategy and optimization.'],
  ['chart-line', 'Analytics & Tracking', 'GA4, GTM, server-side tagging and data layer implementation.'],
  ['chalkboard-user', 'Practical Training', '1,000+ learners trained across digital marketing and tracking.'],
  ['robot', 'AI & Automation', 'Prompt engineering, n8n, Make and AI-assisted marketing workflows.'],
  ['magnifying-glass-chart', 'Measurement Audits', 'Full audit of campaign, tracking and analytics setup.'],
  ['shield-halved', 'Consent Mode', 'Privacy-compliant tracking setup aligned with current requirements.'],
  ['cart-shopping', 'Ecommerce Tracking', 'Enhanced ecommerce and Shopify tracking implementation.'],
  ['people-group', 'Corporate Workshops', 'Structured sessions for teams and institutions.'],
];

document.getElementById('features-grid').innerHTML = features.map(([icon, title, desc]) => `
  <div class="p-5 rounded-2xl border border-white/8 card-hover">
    <i class="fa-solid fa-${icon} text-xl text-violet-400 mb-4" aria-hidden="true"></i>
    <h3 class="font-display font-bold text-sm mb-1.5">${title}</h3>
    <p class="text-xs text-gray-400">${desc}</p>
  </div>`).join('');

// Comparison table
const rows = [
  ['Tracking depth', 'Basic pixel setup', 'Standard GA4 setup', 'Full data layer + server-side'],
  ['Training style', 'Generic templates', 'Slide-based theory', 'Practical, production examples'],
  ['AI & automation', 'Not covered', 'Rarely covered', 'n8n, Make, prompt engineering'],
  ['Post-engagement support', 'Limited', 'Ticket-based', 'Direct, ongoing'],
  ['Measurement audit', 'Not offered', 'Add-on cost', 'Core part of engagement'],
];

document.getElementById('compare-body').innerHTML = rows.map((r, i) => `
  <tr class="${i % 2 === 0 ? 'bg-white/[0.02]' : ''} border-b border-white/5">
    <td class="p-4 text-gray-300 font-medium">${r[0]}</td>
    <td class="p-4 text-gray-400">${r[1]}</td>
    <td class="p-4 text-gray-400">${r[2]}</td>
    <td class="p-4 text-violet-200 font-semibold bg-violet-500/5">${r[3]}</td>
  </tr>`).join('');

// FAQ
const faqs = [
  ['What exactly do you help with?', 'Performance marketing (Google Ads, Meta Ads), analytics & tracking (GA4, GTM, server-side), consulting audits, and training for individuals, teams and institutions.'],
  ['Do I need technical knowledge to work with you?', 'No. Training sessions are built for practical understanding, not prior technical background.'],
  ['Are you an expert in AI and app tracking?', 'AI/automation (n8n, Make, prompt engineering) is an active area of practice. App tracking (Firebase, MMPs, AppsFlyer) is currently being explored — not yet advanced practice. Both are noted transparently.'],
  ['Do you offer corporate training?', 'Yes — workshops, guest sessions and structured training for organizations and institutes.'],
  ['How is pricing decided?', 'Scope and pricing depend on project size and are shared after a short discovery call.'],
  ['How do I get in touch?', 'Email ashmanagerid@gmail.com or connect via LinkedIn — both linked in the contact section.'],
];

document.getElementById('faq-list').innerHTML = faqs.map((f, i) => `
  <div class="accordion-item glass rounded-xl overflow-hidden">
    <button
      class="focus-ring w-full flex items-center justify-between text-left px-5 py-4 font-medium"
      aria-expanded="false"
      aria-controls="faq-panel-${i}"
      data-faq-trigger
    >
      <span>${f[0]}</span>
      <i class="fa-solid fa-chevron-down chev text-xs text-gray-400" aria-hidden="true"></i>
    </button>
    <div class="accordion-content px-5" id="faq-panel-${i}" role="region">
      <p class="text-sm text-gray-400 pb-4">${f[1]}</p>
    </div>
  </div>`).join('');

// Accordion behavior (accessible: toggles aria-expanded)
document.querySelectorAll('[data-faq-trigger]').forEach(btn => {
  btn.addEventListener('click', () => {
    const item = btn.closest('.accordion-item');
    const isOpen = item.classList.toggle('open');
    btn.setAttribute('aria-expanded', String(isOpen));
  });
});

// Reduced motion: disable marquee animation via class toggle (CSS already handles @media,
// this covers browsers where JS-driven checks are needed for consistency)
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
if (reduceMotion) {
  document.querySelectorAll('.marquee-track').forEach(el => {
    el.style.animation = 'none';
  });
}
